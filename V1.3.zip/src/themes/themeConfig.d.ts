import { ThemeConfig } from '../types';

export const GAME_THEMES: Record<string, ThemeConfig>;
export const ICONS: Record<string, any>;
